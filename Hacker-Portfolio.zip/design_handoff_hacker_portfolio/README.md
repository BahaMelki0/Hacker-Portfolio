# Handoff: Matrix-Themed Hacker Portfolio

## Overview

Personal portfolio website for **Bahaeddine Melki** — Pentest Intern at RandoriSec and Post-Master's student at EURECOM × SUP'COM. The design is a Matrix-themed single-page application with a fixed navbar and five stacked sections (Home, About, Projects, Resume, Contact). The visual language leans into "cyberpunk terminal" — falling code rain, CRT scanlines, glitch headings, typewriter command demos — but with a muted phosphor green palette tuned to be readable for long sessions, not screaming neon.

Target deployment: **GitHub Pages**. The app must work from a static host with no backend — use `HashRouter` for navigation and Formspree (or equivalent static form endpoint) for the contact form.

## About the Design Files

The files in `reference/` are **HTML design prototypes** built with inline React via Babel-standalone. They are references for look, behavior, copy, and interactions — **not production code to copy verbatim.** Your job is to **recreate these designs in a proper React project** (Vite + React 18 + React Router is the expected stack) using clean, idiomatic components, real CSS modules or Tailwind, and a real build pipeline.

If the user has not set up a codebase yet, scaffold a fresh one: `npm create vite@latest portfolio -- --template react` → install `react-router-dom` → proceed.

## Fidelity

**High-fidelity.** Colors, typography, spacing, and interactions in the reference are final. Match them closely. The one variation that matters is **Variation A** (long-scroll landing) — ignore B and C which were exploration alternatives.

- Primary reference: `reference/variation-a.jsx` (all sections)
- Shared primitives: `reference/primitives.jsx` (MatrixRain, Glitch, Typewriter, DecryptText, ScrollReveal, PORTFOLIO data, PROJECT_CATS)
- Styles & tokens: `reference/styles.css`

---

## Design Tokens

All defined as CSS custom properties in `styles.css`. Copy these verbatim.

```css
--mx-green:        #6fdc8c;   /* body text — muted mint phosphor */
--mx-green-dim:    #4a8a5a;   /* secondary text, labels */
--mx-green-bright: #a8f0b4;   /* accents, hover, active */
--mx-bg:           #0a100c;   /* page background (soft charcoal-green, NOT pure black) */
--mx-panel:        rgba(20, 30, 22, 0.55);
--mx-border:       rgba(111, 220, 140, 0.18);
--mx-border-strong:rgba(111, 220, 140, 0.42);
--mx-red:          #e56b6b;   /* NDA / warnings / errors */
--mx-amber:        #e0b070;

--mx-font:  "JetBrains Mono", "SF Mono", "Menlo", "Consolas", monospace;
```

**Typography scale** (all monospace, JetBrains Mono from Google Fonts):
- Hero name (Glitch h1): 96px, weight 700, letter-spacing -2px, line-height 1
- Section heading (h2): 40px, weight 700, letter-spacing -1px
- Project card title: 20px, weight 500, letter-spacing -0.3px
- Body: 14px / line-height 1.7
- Nav / labels / dim meta: 11–12px, letter-spacing 0.08–0.1em, uppercase

**Spacing**: section vertical padding 100px, horizontal padding 60px. Gaps between cards/panels 20px.
**Borders**: 1px solid `--mx-border`. No border-radius anywhere — this is a terminal aesthetic, keep every corner hard.
**Glow**: all glow effects are SOFT. Use shadows like `0 0 6–12px rgba(111, 220, 140, 0.2–0.3)` — never the full-saturation neon blowout.

---

## Global Chrome

### Fixed top navbar
- Sticky, `z-index: 40`, `background: rgba(0,5,0,0.85)` with `backdrop-filter: blur(10px)`, bottom border.
- Left: `▌ bmelki` (bright green) + ` @ randorisec : ~ $ ` (dim).
- Center: section links `home / about / projects / resume / contact`. Active link is bright green with `▸` prefix and soft text-shadow glow. Inactive is dim. Click scrolls to section with smooth behavior and ~60px offset for sticky nav.
- Right: `● ONLINE · Sophia Antipolis · FR`.

### Scroll progress bar
2px sticky bar at the top, fills bright green as the user scrolls, soft glow shadow.

### CRT flicker + scanlines
- Whole page has the `mx-crt` class (subtle 6s `brightness` keyframe flicker).
- Hero (and each section) overlays `mx-scanlines` — a 3px repeating green gradient at ~2.5% alpha.

---

## Sections (in order)

### 1. Hero (`#home`)
Full-viewport (min 820px). Matrix rain canvas fills the background at `opacity: 0.5`, fadeColor `rgba(10,16,12,0.1)`. Scanlines overlay at z-index 2.

Content (z-index 5):
- Small dim meta line: `[ system::boot ]  identity: verified · clearance: ops · status: online`
- **Glitch name** `Bahaeddine Melki` (96px). The Glitch component layers a red and a cyan clip-path duplicate that jitters on keyframes `mxGlitchA` / `mxGlitchB`.
- **Typewriter** cycling through 4 taglines (45ms speed, 1600ms pause):
  - "Breaking Azure tenants by day."
  - "Post-Master @ EURECOM × SUP'COM."
  - "Building red-team tooling in Rust."
  - "Poking at LLMs until they lie."
- **Inline terminal panel** (`mx-panel` with macOS-style red/amber/green dots in header): Auto-typing demo. Cycles through real pentest commands (`whoami`, `cat /etc/identity`, `nmap -sS -A target.corp`, `az ad signed-in-user show`, `python3 rat_analyzer.py --sample discord_c2.exe`) with fake output for each (see `getFakeOutput()` in `variation-a.jsx`). Keeps last 6 lines of history fading out.
- Two buttons: **▶ VIEW OPERATIONS** (primary, scrolls to projects) and **⌁ ESTABLISH CONTACT** (secondary, scrolls to contact).
- Bottom-left hint: `↓ scroll  ·  wake up, neo`

### 2. About (`#about`) — `/01 about // the operator`
Two-column grid `1.2fr 1fr`, gap 60px.

**Left**: terminal-style panel with header `~/profile/about.md`. Body prefixed with `$ cat about.md`. Bio paragraph (bright green, pre-line):
> Pentest Intern at RandoriSec and Post-Master's student at EURECOM in the SUP'COM × EURECOM program — Security of Computer Systems and Communications. I like shells on cloud tenants, adversarial ML, and writing tools that are uncomfortably effective.

Then a two-column key/value block: `role`, `study`, `focus`, `languages`, `pgp`.

**Right**: skill grid with **tabs** (Security / Tooling / AI-ML). Each tab shows a 2-column grid of skill cards. Card shows skill name + a hex index (`0x01`, `0x02`...) + a 2px green progress bar (width computed deterministically per skill). Active tab has bottom-border + bright color.

Skills data lives in `PORTFOLIO.skills` in `primitives.jsx`.

### 3. Projects (`#projects`) — `/02 projects // operations log`
Section background: `rgba(0, 10, 2, 0.4)` tint.

- **Filter bar** (top): `All / Security / AI / Systems / Web` — buttons with count badges `[N]`. Active filter has `rgba(111,220,140,0.15)` fill.
- **2-column grid** of project cards (`mx-card`). Each card:
  - Meta line: `[YEAR] · CATEGORY · status`
  - Title uses `<DecryptText trigger="hover">` — letters scramble through `01!<>-_\/[]{}=+*^?#` then resolve over 600ms on hover.
  - Summary text (13px, opacity 0.85).
  - Stack tags at the bottom.
  - Top-right: either `[⚠ NDA]` tag (red variant) **or** `git ↗` link for non-private projects.

Project data (6 projects total) is in `PORTFOLIO.projects`. The Azure Red Team Arsenal project has `nda: true`.

### 4. Resume (`#resume`) — `/03 resume // career trace`
Single panel `~/resume/bahaeddine_melki.log · size 4.2kB` with a `↓ download pdf` link in the panel header (right-aligned).

Inside: 4 entries in a two-column grid (`160px 1fr` — date on left, role/org/bullets on right). Dashed bottom border between entries. Each entry:
- Date range (dim, 12px)
- `{role} · {org}` (bright, 16px)
- Bullet list with `▸` markers

Data in `PORTFOLIO.experience`.

### 5. Contact (`#contact`) — `/04 contact // secure channel`
Section background: `rgba(0, 10, 2, 0.4)`. Two-column `1fr 1fr`, gap 60px.

**Left column**: heading, 2-paragraph blurb, key/value contact block (`mail`, `git`, `in`, `pgp`), and a dashed-border operational-note callout.

**Right column**: form in a `mx-panel` titled `/bin/contact · TLS 1.3`.
- Fields: `callsign` (name), `uplink` (email), `payload` (textarea). Each field has a dim uppercase label prefixed `>` and a red `*` for required.
- Submit button: **▶ TRANSMIT** (full-width, primary).
- On submit → swap form for success state: `▶ Packet transmitted. > echo will reach you at {email}`.
- **Implementation**: POST to Formspree endpoint. Keep the existing visual states; only swap the network call. Handle error state with a dim red message.

### Footer
1px top border, dim 11px text, three columns:
- `© MMXXVI · Bahaeddine Melki · all rights unreserved`
- `built with ▌ + █ + rain`
- `the system has you · follow the white rabbit ⌁`

---

## Reusable Components / Primitives

All in `reference/primitives.jsx` — port them to separate files in `src/components/`:

### `<MatrixRain density opacity color fadeColor fontSize />`
Canvas that fills its parent (`position: absolute; inset: 0`). Uses katakana + latin + digits glyph pool. Renders at **30fps desktop / 15fps mobile** (media-query check). Pauses on `document.hidden`. Uses `ResizeObserver` to handle parent resize. DPR-aware (caps at 2).

### `<Glitch as="h1">text</Glitch>`
CSS-only glitch effect. Main element has `mx-glitch` class + `data-text={text}` attribute. `::before` and `::after` pseudos render duplicate text in red and cyan, clipped to top/bottom halves, with jitter keyframes running on 3.2s / 4.1s cycles.

### `<Typewriter lines speed pause loop cursor />`
Types through an array of strings, pauses, deletes, advances. Shows blinking `▋` caret.

### `<DecryptText text trigger="mount|hover" duration />`
Scrambles characters through a random pool, resolves left-to-right over `duration` ms. Re-runs on hover if `trigger="hover"`.

### `<ScrollReveal delay y root>`
Wraps children, fades + translates them in when they enter the viewport. Pass `root={scrollContainer}` since the reference scrolls inside a bounded container — in the real site it should use `root: null` (document viewport) unless you keep the boxed layout.

---

## Behavior / State

- **Scroll tracking**: listen to scroll on the root container (or `window`). Determine active section by finding the section whose `offsetTop - scrollTop ≤ 120`. Update navbar active state + progress bar width.
- **Smooth scroll**: clicking nav → `window.scrollTo({ top: section.offsetTop - 60, behavior: 'smooth' })`.
- **Page fade transition between routes**: if you keep HashRouter for multi-page (it isn't strictly needed — this is really one page), wrap `<Routes>` in a 200ms opacity fade keyed on `location.pathname`.
- **Tabs**: `useState('Security')` for skill category.
- **Project filter**: `useState('All')` for project category.
- **Contact form**: controlled inputs, `useState({ sent: false, error: null })` for submission state.
- **Performance**: MatrixRain MUST pause on hidden tabs (already implemented in primitive). Keep density ≤ 1.1 on desktop, ≤ 0.7 on mobile.

---

## Responsive

Breakpoints: `≤ 768px` is mobile.
- Navbar: collapse center links into a hamburger → slide-down menu.
- Hero name: scale down to 56px on mobile, 40px on narrow phones.
- All 2-column grids (`about`, `projects`, `contact`) collapse to single column.
- Section padding: reduce to `60px 20px` on mobile.
- MatrixRain density: 0.7 on mobile (already conditionally set in primitive).

---

## Data

`PORTFOLIO` object in `primitives.jsx` contains all content — name, handle, title, locale, tagline, bio, skills (categorized), 6 projects with stack/summary/year/status/nda, 4 experience entries, contact block. Lift it into `src/data/portfolio.js` as the single source of truth. `PROJECT_CATS = ['All', 'Security', 'AI', 'Systems', 'Web']`.

## Assets

- **Font**: JetBrains Mono from Google Fonts (weights 400/500/600/700).
- **Resume PDF**: user will provide; link from the resume panel header and from Contact.
- No other images or icons — the design uses Unicode glyphs (`▶ ▸ ◉ ◈ ▤ ✉ ⌁ █ ▌ ◂`) for all iconography. Do not swap these for an icon library.

## Files in `reference/`

- `variation-a.jsx` — the full chosen design (Hero, About, Projects, Resume, Contact, Footer + helpers)
- `primitives.jsx` — MatrixRain, Glitch, Typewriter, DecryptText, ScrollReveal, PORTFOLIO data
- `styles.css` — all CSS tokens, classes (`mx-panel`, `mx-btn`, `mx-card`, `mx-tag`, `mx-input`, etc.), keyframes (`mxGlitchA`, `mxGlitchB`, `mxBlink`, `mxFlicker`)
- `Hacker Portfolio.html` — entry point
- `design-canvas.jsx` — preview wrapper used in the design doc (IGNORE when shipping)

## Out of scope / do not build

- Variations B (CLI) and C (OS dashboard) from the design canvas — reference only.
- Server, database, auth — none needed.
- Analytics / tracking.
- GitHub activity calendar (user specifically opted out).
- Blog / writing section.

## Acceptance checklist

- [ ] Builds with `vite build`, deploys to GitHub Pages via `gh-pages` branch or Actions.
- [ ] HashRouter used; refresh on any "route" works.
- [ ] Matrix rain visible in hero, runs at 30fps (15fps mobile), pauses on hidden tab.
- [ ] Glitch name animates on hero.
- [ ] Typewriter cycles 4 taglines in hero.
- [ ] Inline hero terminal auto-types 5 commands on loop with output.
- [ ] Nav highlights the correct active section as you scroll.
- [ ] Progress bar fills as you scroll.
- [ ] Skill tabs work; project filter works; decrypt-on-hover works on project titles.
- [ ] NDA badge shows on Azure project, git link on all others.
- [ ] Contact form submits to Formspree; success state swaps in.
- [ ] Fully responsive down to 360px wide.
- [ ] Palette matches `--mx-*` tokens exactly — no neon blowout.
