// Variation A — Classic long-scroll landing page.
// Fixed navbar · full-viewport hero with matrix rain + glitch + typewriter
// · About with terminal-box bio + tabbed skill grid
// · Projects with category filter + cards
// · Resume terminal box + download
// · Contact form (Formspree-style, stubbed)
// Scroll progress bar at top.

function VariationA() {
  const rootRef = React.useRef(null);
  const [active, setActive] = React.useState('home');
  const [progress, setProgress] = React.useState(0);
  const [skillTab, setSkillTab] = React.useState('Security');
  const [projCat, setProjCat] = React.useState('All');
  const [formState, setFormState] = React.useState({ name: '', email: '', msg: '', sent: false });

  const filtered = PORTFOLIO.projects.filter(p => projCat === 'All' || p.cat === projCat);

  const sections = ['home', 'about', 'projects', 'resume', 'contact'];

  // scroll tracking scoped to the artboard
  const onScroll = (e) => {
    const el = e.currentTarget;
    const pct = el.scrollTop / (el.scrollHeight - el.clientHeight);
    setProgress(Math.max(0, Math.min(1, pct)));
    // find active section
    const sectionEls = sections.map(id => el.querySelector(`[data-sec="${id}"]`));
    let cur = 'home';
    for (let i = 0; i < sectionEls.length; i++) {
      const s = sectionEls[i];
      if (!s) continue;
      if (s.offsetTop - el.scrollTop <= 120) cur = sections[i];
    }
    setActive(cur);
  };

  const scrollTo = (id) => {
    const sec = rootRef.current?.querySelector(`[data-sec="${id}"]`);
    if (sec) {
      rootRef.current.scrollTo({ top: sec.offsetTop - 60, behavior: 'smooth' });
    }
  };

  const submit = (e) => {
    e.preventDefault();
    setFormState(s => ({ ...s, sent: true }));
  };

  return (
    <div
      ref={rootRef}
      className="mx-scroll mx-crt"
      onScroll={onScroll}
      style={{
        width: '100%',
        height: '100%',
        overflowY: 'auto',
        overflowX: 'hidden',
        background: 'var(--mx-bg)',
        color: 'var(--mx-green)',
        fontFamily: 'var(--mx-font)',
        position: 'relative',
      }}
    >
      {/* progress bar */}
      <div className="mx-progress" style={{ width: `${progress * 100}%`, position: 'sticky' }} />

      {/* nav */}
      <nav style={{
        position: 'sticky', top: 0, zIndex: 40,
        background: 'rgba(0,5,0,0.85)',
        backdropFilter: 'blur(10px)',
        borderBottom: '1px solid var(--mx-border)',
        padding: '14px 40px',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        fontSize: 13,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <span className="mx-hl" style={{ fontWeight: 600 }}>▌ {PORTFOLIO.handle}</span>
          <span className="mx-dim" style={{ fontSize: 11 }}>@ randorisec : ~ $</span>
        </div>
        <div style={{ display: 'flex', gap: 4 }}>
          {sections.map(s => (
            <button key={s} onClick={() => scrollTo(s)}
              style={{
                background: 'transparent',
                border: 'none',
                color: active === s ? 'var(--mx-green-bright)' : 'var(--mx-green-dim)',
                fontFamily: 'var(--mx-font)',
                fontSize: 12,
                cursor: 'pointer',
                padding: '6px 12px',
                textTransform: 'uppercase',
                letterSpacing: '0.08em',
                textShadow: active === s ? '0 0 8px rgba(0,255,65,0.7)' : 'none',
                position: 'relative',
              }}>
              {active === s && <span style={{ marginRight: 6 }}>▸</span>}
              {s}
            </button>
          ))}
        </div>
        <div style={{ fontSize: 11, color: 'var(--mx-green-dim)' }}>
          <span style={{ color: 'var(--mx-green)' }}>●</span> ONLINE · {PORTFOLIO.locale}
        </div>
      </nav>

      {/* ─── HERO ─── */}
      <section data-sec="home" style={{
        position: 'relative',
        minHeight: 820,
        padding: '80px 60px 120px',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        overflow: 'hidden',
      }}>
        <div style={{ position: 'absolute', inset: 0, zIndex: 0 }}>
          <MatrixRain density={1.1} opacity={0.5} color="#6fdc8c" fadeColor="rgba(10,16,12,0.1)" />
        </div>
        <div className="mx-scanlines" style={{ position: 'absolute', inset: 0, zIndex: 2, pointerEvents: 'none' }} />

        <div style={{ position: 'relative', zIndex: 5, maxWidth: 900 }}>
          <div style={{ color: 'var(--mx-green-dim)', fontSize: 12, letterSpacing: '0.2em', marginBottom: 20 }}>
            <span className="mx-hl">[ system::boot ]</span> &nbsp; identity: verified &nbsp;·&nbsp; clearance: ops &nbsp;·&nbsp; status: <span className="mx-hl">online</span>
          </div>

          <Glitch as="h1" style={{
            fontSize: 96,
            fontWeight: 700,
            letterSpacing: -2,
            margin: '0 0 12px',
            lineHeight: 1,
            fontFamily: 'var(--mx-font)',
          }}>{PORTFOLIO.name}</Glitch>

          <div style={{
            fontSize: 22,
            color: 'var(--mx-green-bright)',
            margin: '0 0 36px',
            opacity: 0.9,
          }}>
            ▶ <Typewriter lines={PORTFOLIO.tagline} speed={45} pause={1600} />
          </div>

          {/* inline terminal preview */}
          <div className="mx-panel" style={{ maxWidth: 680, marginBottom: 36 }}>
            <div className="mx-panel-head">
              <span className="mx-panel-dots"><span/><span/><span/></span>
              <span>/dev/tty0 · bmelki@matrix</span>
            </div>
            <div style={{ padding: '16px 18px', fontSize: 13, lineHeight: 1.7 }}>
              <HeroTerminal />
            </div>
          </div>

          <div style={{ display: 'flex', gap: 14 }}>
            <button className="mx-btn mx-btn-primary" onClick={() => scrollTo('projects')}>
              <span>▶</span> View Operations
            </button>
            <button className="mx-btn" onClick={() => scrollTo('contact')}>
              <span>⌁</span> Establish Contact
            </button>
          </div>

          <div style={{
            position: 'absolute',
            bottom: -60,
            left: 0,
            color: 'var(--mx-green-dim)',
            fontSize: 11,
            letterSpacing: '0.15em',
            textTransform: 'uppercase',
          }}>
            ↓ scroll &nbsp; · &nbsp; wake up, neo
          </div>
        </div>
      </section>

      {/* ─── ABOUT ─── */}
      <section data-sec="about" style={{ padding: '100px 60px', position: 'relative' }}>
        <SecHeader num="01" title="about" sub="// the operator" />
        <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 1fr', gap: 60, marginTop: 40 }}>
          <ScrollReveal root={rootRef.current}>
            <div className="mx-panel">
              <div className="mx-panel-head">
                <span className="mx-panel-dots"><span/><span/><span/></span>
                <span>~/profile/about.md</span>
              </div>
              <div style={{ padding: '20px 22px', fontSize: 14, lineHeight: 1.7 }}>
                <div style={{ color: 'var(--mx-green-dim)', marginBottom: 12 }}>
                  <span className="mx-hl">$</span> cat about.md
                </div>
                <p style={{ margin: '0 0 18px', whiteSpace: 'pre-line', color: 'var(--mx-green-bright)' }}>
                  {PORTFOLIO.bio}
                </p>
                <div style={{ display: 'grid', gridTemplateColumns: 'auto 1fr', gap: '6px 16px', fontSize: 13 }}>
                  <span className="mx-dim">role</span>      <span>Pentest Intern @ <span className="mx-hl">RandoriSec</span></span>
                  <span className="mx-dim">study</span>     <span>Post-Master · <span className="mx-hl">EURECOM × SUP'COM</span></span>
                  <span className="mx-dim">focus</span>     <span>Azure red team · Adversarial AI · C2 dev</span>
                  <span className="mx-dim">languages</span> <span>FR · EN · AR</span>
                  <span className="mx-dim">pgp</span>       <span className="mx-mono">{PORTFOLIO.contact.pgp}</span>
                </div>
              </div>
            </div>
          </ScrollReveal>

          <ScrollReveal root={rootRef.current} delay={120}>
            <div>
              <div style={{ display: 'flex', gap: 0, marginBottom: 16, borderBottom: '1px solid var(--mx-border)' }}>
                {Object.keys(PORTFOLIO.skills).map(cat => (
                  <button key={cat} onClick={() => setSkillTab(cat)}
                    style={{
                      background: 'transparent',
                      border: 'none',
                      borderBottom: skillTab === cat ? '2px solid var(--mx-green)' : '2px solid transparent',
                      color: skillTab === cat ? 'var(--mx-green-bright)' : 'var(--mx-green-dim)',
                      fontFamily: 'var(--mx-font)',
                      fontSize: 12,
                      padding: '10px 16px',
                      cursor: 'pointer',
                      textTransform: 'uppercase',
                      letterSpacing: '0.1em',
                      marginBottom: -1,
                    }}>
                    {cat}
                  </button>
                ))}
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 8 }}>
                {PORTFOLIO.skills[skillTab].map((skill, i) => (
                  <div key={skill} className="mx-card" style={{ padding: '12px 14px', cursor: 'default' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <span className="mx-hl" style={{ fontSize: 13 }}>{skill}</span>
                      <span className="mx-dim" style={{ fontSize: 10 }}>0x{(i + 1).toString(16).padStart(2, '0')}</span>
                    </div>
                    <div style={{
                      marginTop: 6,
                      height: 2,
                      background: 'var(--mx-border)',
                    }}>
                      <div style={{
                        height: '100%',
                        width: `${70 + (skill.length * 2) % 25}%`,
                        background: 'var(--mx-green)',
                        boxShadow: '0 0 6px var(--mx-green)',
                      }} />
                    </div>
                  </div>
                ))}
              </div>
              <div style={{ marginTop: 16, color: 'var(--mx-green-dim)', fontSize: 11 }}>
                ▸ {PORTFOLIO.skills[skillTab].length} modules loaded · tab to switch
              </div>
            </div>
          </ScrollReveal>
        </div>
      </section>

      {/* ─── PROJECTS ─── */}
      <section data-sec="projects" style={{ padding: '100px 60px', background: 'rgba(0, 10, 2, 0.4)' }}>
        <SecHeader num="02" title="projects" sub="// operations log" />
        <div style={{ display: 'flex', gap: 8, margin: '40px 0 28px', flexWrap: 'wrap' }}>
          {PROJECT_CATS.map(cat => {
            const count = cat === 'All' ? PORTFOLIO.projects.length : PORTFOLIO.projects.filter(p => p.cat === cat).length;
            return (
              <button key={cat} onClick={() => setProjCat(cat)} className="mx-btn"
                style={{
                  background: projCat === cat ? 'rgba(0,255,65,0.15)' : 'transparent',
                  borderColor: projCat === cat ? 'var(--mx-green)' : 'var(--mx-border)',
                  color: projCat === cat ? 'var(--mx-green-bright)' : 'var(--mx-green)',
                }}>
                {cat} <span className="mx-dim" style={{ marginLeft: 4, fontSize: 10 }}>[{count}]</span>
              </button>
            );
          })}
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 20 }}>
          {filtered.map((p, i) => (
            <ScrollReveal key={p.id} root={rootRef.current} delay={i * 60}>
              <div className="mx-card" style={{ padding: '22px 22px 20px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 }}>
                  <div>
                    <div style={{ color: 'var(--mx-green-dim)', fontSize: 11, marginBottom: 6 }}>
                      [{p.year}] · <span style={{ color: 'var(--mx-green)' }}>{p.cat.toUpperCase()}</span> · <span className={p.status === 'active' ? 'mx-hl' : 'mx-dim'}>{p.status}</span>
                    </div>
                    <h3 style={{ margin: 0, fontSize: 20, color: 'var(--mx-green-bright)', letterSpacing: -0.3 }}>
                      <DecryptText text={p.name} trigger="hover" duration={600} />
                    </h3>
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    {p.nda
                      ? <span className="mx-tag mx-tag-nda">⚠ NDA</span>
                      : <a href="#" className="mx-link" style={{ fontSize: 11 }} onClick={e => e.preventDefault()}>git ↗</a>
                    }
                  </div>
                </div>
                <p style={{ margin: '0 0 14px', color: 'var(--mx-green)', opacity: 0.85, fontSize: 13, lineHeight: 1.55 }}>
                  {p.summary}
                </p>
                <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                  {p.stack.map(s => <span key={s} className="mx-tag">{s}</span>)}
                </div>
              </div>
            </ScrollReveal>
          ))}
        </div>
      </section>

      {/* ─── RESUME ─── */}
      <section data-sec="resume" style={{ padding: '100px 60px' }}>
        <SecHeader num="03" title="resume" sub="// career trace" />
        <div className="mx-panel" style={{ marginTop: 40 }}>
          <div className="mx-panel-head">
            <span className="mx-panel-dots"><span/><span/><span/></span>
            <span>~/resume/bahaeddine_melki.log · size 4.2kB</span>
            <span style={{ marginLeft: 'auto' }}>
              <a href="#" className="mx-link" style={{ fontSize: 11 }} onClick={e => e.preventDefault()}>
                ↓ download pdf
              </a>
            </span>
          </div>
          <div style={{ padding: '24px 28px' }}>
            {PORTFOLIO.experience.map((ex, i) => (
              <ScrollReveal key={i} root={rootRef.current} delay={i * 80}>
                <div style={{
                  display: 'grid', gridTemplateColumns: '160px 1fr',
                  gap: 24, padding: '16px 0',
                  borderBottom: i < PORTFOLIO.experience.length - 1 ? '1px dashed var(--mx-border)' : 'none',
                }}>
                  <div className="mx-dim" style={{ fontSize: 12, paddingTop: 3 }}>
                    <div>{ex.date}</div>
                  </div>
                  <div>
                    <div style={{ fontSize: 16, color: 'var(--mx-green-bright)', fontWeight: 500 }}>
                      {ex.role} <span className="mx-dim" style={{ fontSize: 13, fontWeight: 400 }}>· {ex.org}</span>
                    </div>
                    <ul style={{ margin: '8px 0 0', paddingLeft: 0, listStyle: 'none' }}>
                      {ex.bullets.map(b => (
                        <li key={b} style={{ fontSize: 13, color: 'var(--mx-green)', opacity: 0.85, padding: '2px 0' }}>
                          <span className="mx-dim">▸</span> {b}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>

      {/* ─── CONTACT ─── */}
      <section data-sec="contact" style={{ padding: '100px 60px 140px', background: 'rgba(0, 10, 2, 0.4)' }}>
        <SecHeader num="04" title="contact" sub="// secure channel" />
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 60, marginTop: 40 }}>
          <ScrollReveal root={rootRef.current}>
            <div style={{ fontSize: 14, lineHeight: 1.7 }}>
              <p style={{ margin: '0 0 20px', color: 'var(--mx-green-bright)', fontSize: 16 }}>
                Incoming transmissions welcome.
              </p>
              <p style={{ margin: '0 0 24px', color: 'var(--mx-green)', opacity: 0.85 }}>
                For engagements, research collaboration, or a coffee — send a packet.
                Responses within 48h. Encrypted mail preferred.
              </p>
              <div style={{ display: 'grid', gap: 10, fontSize: 13 }}>
                <div><span className="mx-dim">mail</span>&nbsp;&nbsp;&nbsp;&nbsp;<a className="mx-link" href={`mailto:${PORTFOLIO.contact.email}`}>{PORTFOLIO.contact.email}</a></div>
                <div><span className="mx-dim">git</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a className="mx-link" href="#" onClick={e=>e.preventDefault()}>{PORTFOLIO.contact.github}</a></div>
                <div><span className="mx-dim">in</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a className="mx-link" href="#" onClick={e=>e.preventDefault()}>{PORTFOLIO.contact.linkedin}</a></div>
                <div><span className="mx-dim">pgp</span>&nbsp;&nbsp;&nbsp;&nbsp;<span className="mx-mono">{PORTFOLIO.contact.pgp}</span></div>
              </div>

              <div style={{ marginTop: 36, padding: 14, border: '1px dashed var(--mx-border)', fontSize: 11, color: 'var(--mx-green-dim)' }}>
                <div className="mx-hl" style={{ marginBottom: 4 }}>⚠ operational note</div>
                For sensitive disclosures, use PGP or Signal. Never send client data
                in cleartext. The system is listening.
              </div>
            </div>
          </ScrollReveal>

          <ScrollReveal root={rootRef.current} delay={100}>
            <form onSubmit={submit} className="mx-panel">
              <div className="mx-panel-head">
                <span className="mx-panel-dots"><span/><span/><span/></span>
                <span>/bin/contact · TLS 1.3</span>
              </div>
              <div style={{ padding: '22px 24px' }}>
                {formState.sent ? (
                  <div style={{ padding: '40px 0', textAlign: 'center' }}>
                    <div style={{ fontSize: 40, marginBottom: 12 }}>▶</div>
                    <div className="mx-hl" style={{ fontSize: 18, marginBottom: 8 }}>Packet transmitted.</div>
                    <div className="mx-dim" style={{ fontSize: 13 }}>&gt; echo will reach you at {formState.email || '—'}</div>
                  </div>
                ) : (
                  <>
                    <FormField label="callsign" required>
                      <input className="mx-input" value={formState.name} required
                        onChange={e => setFormState(s => ({ ...s, name: e.target.value }))}
                        placeholder="your name" />
                    </FormField>
                    <FormField label="uplink" required>
                      <input className="mx-input" type="email" value={formState.email} required
                        onChange={e => setFormState(s => ({ ...s, email: e.target.value }))}
                        placeholder="you@domain.tld" />
                    </FormField>
                    <FormField label="payload" required>
                      <textarea className="mx-textarea" rows={5} value={formState.msg} required
                        onChange={e => setFormState(s => ({ ...s, msg: e.target.value }))}
                        placeholder="encrypted message..." />
                    </FormField>
                    <button type="submit" className="mx-btn mx-btn-primary" style={{ width: '100%', justifyContent: 'center', marginTop: 8 }}>
                      ▶ TRANSMIT
                    </button>
                  </>
                )}
              </div>
            </form>
          </ScrollReveal>
        </div>
      </section>

      {/* footer */}
      <footer style={{
        borderTop: '1px solid var(--mx-border)',
        padding: '24px 60px',
        display: 'flex',
        justifyContent: 'space-between',
        fontSize: 11,
        color: 'var(--mx-green-dim)',
      }}>
        <span>© MMXXVI · {PORTFOLIO.name} · all rights unreserved</span>
        <span>built with ▌ + █ + rain</span>
        <span>the system has you · follow the white rabbit ⌁</span>
      </footer>
    </div>
  );
}

function SecHeader({ num, title, sub }) {
  return (
    <div style={{ display: 'flex', alignItems: 'baseline', gap: 18, borderBottom: '1px solid var(--mx-border)', paddingBottom: 14 }}>
      <span className="mx-dim" style={{ fontSize: 12, fontFamily: 'var(--mx-font)' }}>/{num}</span>
      <h2 style={{
        margin: 0, fontSize: 40, fontWeight: 700, letterSpacing: -1,
        color: 'var(--mx-green-bright)',
        textShadow: '0 0 10px rgba(0,255,65,0.4)',
        fontFamily: 'var(--mx-font)',
      }}>{title}</h2>
      <span className="mx-dim" style={{ fontSize: 13 }}>{sub}</span>
    </div>
  );
}

function FormField({ label, required, children }) {
  return (
    <div style={{ marginBottom: 14 }}>
      <div style={{ fontSize: 11, color: 'var(--mx-green-dim)', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.1em' }}>
        &gt; {label} {required && <span style={{ color: 'var(--mx-red)' }}>*</span>}
      </div>
      {children}
    </div>
  );
}

function HeroTerminal() {
  const [lineIdx, setLineIdx] = React.useState(0);
  const [history, setHistory] = React.useState([]);
  const [current, setCurrent] = React.useState('');
  const [typing, setTyping] = React.useState(true);

  React.useEffect(() => {
    const cmd = PORTFOLIO.terminalDemo[lineIdx % PORTFOLIO.terminalDemo.length];
    if (typing) {
      if (current.length < cmd.length) {
        const t = setTimeout(() => setCurrent(cmd.slice(0, current.length + 1)), 40 + Math.random() * 40);
        return () => clearTimeout(t);
      }
      // done typing → show output
      const out = getFakeOutput(cmd);
      const t = setTimeout(() => {
        setHistory(h => [...h.slice(-6), { cmd, out }]);
        setCurrent('');
        setTyping(false);
      }, 500);
      return () => clearTimeout(t);
    } else {
      const t = setTimeout(() => {
        setLineIdx(i => i + 1);
        setTyping(true);
      }, 1800);
      return () => clearTimeout(t);
    }
  }, [current, typing, lineIdx]);

  return (
    <div>
      {history.map((h, i) => (
        <div key={i} style={{ opacity: 1 - (history.length - 1 - i) * 0.12 }}>
          <div><span className="mx-hl">▸</span> <span className="mx-dim">{h.cmd}</span></div>
          <div style={{ color: 'var(--mx-green)', opacity: 0.8, paddingLeft: 14, whiteSpace: 'pre' }}>{h.out}</div>
        </div>
      ))}
      <div>
        <span className="mx-hl">▸</span>{' '}
        <span className="mx-hl">{current}</span>
        {typing && <span className="mx-caret">▋</span>}
      </div>
    </div>
  );
}

function getFakeOutput(cmd) {
  if (cmd.startsWith('whoami')) return 'bmelki (uid=1337) groups=redteam,eurecom';
  if (cmd.startsWith('cat /etc/identity')) return 'Bahaeddine Melki · Offensive Security · FR/TN';
  if (cmd.startsWith('nmap')) return 'Host is up. 22/tcp open, 443/tcp open, 3389/tcp filtered';
  if (cmd.startsWith('az ad')) return 'userPrincipalName: svc_backup@tenant.onmicrosoft.com · MFA: disabled ⚠';
  if (cmd.startsWith('python3')) return '[+] C2 channel detected · discord://gateway · entropy=7.8';
  return 'ok.';
}

Object.assign(window, { VariationA });
