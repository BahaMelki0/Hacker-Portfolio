// Shared primitives for the Matrix-themed portfolio.
// Everything is scoped to work inside a bounded container (no fixed-to-viewport
// elements) so these can live inside design-canvas artboards.

// ─────────────────────────────────────────────────────────────
// MatrixRain — canvas that fills its parent; katakana + latin + digits.
// Automatically throttles on mobile / hidden tabs.
// ─────────────────────────────────────────────────────────────
function MatrixRain({ density = 1, opacity = 0.9, color = '#00FF41', fadeColor = 'rgba(0,0,0,0.08)', fontSize = 15 }) {
  const ref = React.useRef(null);
  React.useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const parent = canvas.parentElement;
    let cols = 0;
    let drops = [];
    let w = 0, h = 0;

    const glyphs = 'ｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾅﾆﾇﾈﾉﾊﾋﾌﾍﾎﾏﾐﾑﾒﾓﾔﾕﾖﾗﾘﾙﾚﾛﾜﾝ0123456789<>[]{}/\\|=+*ABCDEF';

    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      w = parent.clientWidth;
      h = parent.clientHeight;
      canvas.width = w * dpr;
      canvas.height = h * dpr;
      canvas.style.width = w + 'px';
      canvas.style.height = h + 'px';
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      cols = Math.floor((w / fontSize) * density);
      drops = new Array(cols).fill(0).map(() => Math.random() * (h / fontSize));
    };
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(parent);

    const isMobile = window.matchMedia('(max-width: 768px)').matches;
    const targetFps = isMobile ? 15 : 30;
    const frameMs = 1000 / targetFps;

    let last = 0;
    let raf = 0;
    let running = true;
    const tick = (ts) => {
      if (!running) return;
      raf = requestAnimationFrame(tick);
      if (ts - last < frameMs) return;
      last = ts;

      ctx.fillStyle = fadeColor;
      ctx.fillRect(0, 0, w, h);

      ctx.font = `${fontSize}px "JetBrains Mono","SF Mono",Consolas,monospace`;
      ctx.textBaseline = 'top';

      for (let i = 0; i < cols; i++) {
        const x = i * (w / cols);
        const y = drops[i] * fontSize;
        const ch = glyphs[Math.floor(Math.random() * glyphs.length)];
        // bright head
        if (Math.random() < 0.02) {
          ctx.fillStyle = '#CFFFCF';
        } else {
          ctx.fillStyle = color;
        }
        ctx.globalAlpha = opacity;
        ctx.fillText(ch, x, y);
        ctx.globalAlpha = 1;

        if (y > h && Math.random() > 0.975) drops[i] = 0;
        drops[i] += 1;
      }
    };
    raf = requestAnimationFrame(tick);

    const onVis = () => {
      running = !document.hidden;
      if (running) raf = requestAnimationFrame(tick);
    };
    document.addEventListener('visibilitychange', onVis);

    return () => {
      running = false;
      cancelAnimationFrame(raf);
      ro.disconnect();
      document.removeEventListener('visibilitychange', onVis);
    };
  }, [density, opacity, color, fadeColor, fontSize]);

  return <canvas ref={ref} style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }} />;
}

// ─────────────────────────────────────────────────────────────
// Glitch — distorted duplicate layers for a heading
// ─────────────────────────────────────────────────────────────
function Glitch({ children, as = 'h1', style = {}, intensity = 1 }) {
  const Tag = as;
  const text = typeof children === 'string' ? children : '';
  return (
    <Tag className="mx-glitch" data-text={text} style={style}>{children}</Tag>
  );
}

// ─────────────────────────────────────────────────────────────
// Typewriter — types text, optionally cycles through a list
// ─────────────────────────────────────────────────────────────
function Typewriter({ lines, speed = 55, pause = 1400, cursor = true, loop = true, onDone }) {
  const [i, setI] = React.useState(0);
  const [sub, setSub] = React.useState('');
  const [deleting, setDeleting] = React.useState(false);
  const arr = Array.isArray(lines) ? lines : [lines];

  React.useEffect(() => {
    const cur = arr[i % arr.length];
    if (!deleting && sub === cur) {
      if (!loop && i === arr.length - 1) { onDone && onDone(); return; }
      const t = setTimeout(() => setDeleting(true), pause);
      return () => clearTimeout(t);
    }
    if (deleting && sub === '') {
      setDeleting(false);
      setI((x) => x + 1);
      return;
    }
    const t = setTimeout(() => {
      setSub((s) => deleting ? cur.slice(0, s.length - 1) : cur.slice(0, s.length + 1));
    }, deleting ? speed / 2 : speed);
    return () => clearTimeout(t);
  }, [sub, deleting, i, arr, speed, pause, loop]);

  return (
    <span className="mx-type">{sub}{cursor && <span className="mx-caret">▋</span>}</span>
  );
}

// ─────────────────────────────────────────────────────────────
// DecryptText — letters scramble then resolve on mount or hover
// ─────────────────────────────────────────────────────────────
function DecryptText({ text, trigger = 'mount', duration = 900, style, className }) {
  const [out, setOut] = React.useState(text);
  const raf = React.useRef(0);
  const chars = '01!<>-_\\/[]{}=+*^?#________';

  const run = React.useCallback(() => {
    cancelAnimationFrame(raf.current);
    const start = performance.now();
    const step = (now) => {
      const p = Math.min(1, (now - start) / duration);
      let s = '';
      for (let i = 0; i < text.length; i++) {
        if (text[i] === ' ') { s += ' '; continue; }
        const reveal = p * text.length;
        if (i < reveal - 3) s += text[i];
        else s += chars[Math.floor(Math.random() * chars.length)];
      }
      setOut(s);
      if (p < 1) raf.current = requestAnimationFrame(step);
      else setOut(text);
    };
    raf.current = requestAnimationFrame(step);
  }, [text, duration]);

  React.useEffect(() => {
    if (trigger === 'mount') run();
    return () => cancelAnimationFrame(raf.current);
  }, [run, trigger]);

  const hoverProps = trigger === 'hover' ? { onMouseEnter: run } : {};
  return <span className={className} style={style} {...hoverProps}>{out}</span>;
}

// ─────────────────────────────────────────────────────────────
// ScrollReveal — fade + slide in when element enters viewport
// (scoped to artboard via root prop)
// ─────────────────────────────────────────────────────────────
function ScrollReveal({ children, delay = 0, y = 18, root = null }) {
  const ref = React.useRef(null);
  const [shown, setShown] = React.useState(false);
  React.useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver((entries) => {
      for (const e of entries) {
        if (e.isIntersecting) { setShown(true); io.disconnect(); }
      }
    }, { threshold: 0.15, root });
    io.observe(el);
    return () => io.disconnect();
  }, [root]);
  return (
    <div ref={ref} style={{
      opacity: shown ? 1 : 0,
      transform: shown ? 'translateY(0)' : `translateY(${y}px)`,
      transition: `opacity 700ms cubic-bezier(.2,.7,.3,1) ${delay}ms, transform 700ms cubic-bezier(.2,.7,.3,1) ${delay}ms`,
    }}>{children}</div>
  );
}

// ─────────────────────────────────────────────────────────────
// Data: Bahaeddine's actual portfolio content
// ─────────────────────────────────────────────────────────────
const PORTFOLIO = {
  name: 'Bahaeddine Melki',
  handle: 'bmelki',
  title: 'Offensive Security Researcher',
  locale: 'Sophia Antipolis · FR',
  tagline: [
    'Breaking Azure tenants by day.',
    'Post-Master @ EURECOM × SUP\'COM.',
    'Building red-team tooling in Rust.',
    'Poking at LLMs until they lie.',
  ],
  terminalDemo: [
    'whoami',
    'cat /etc/identity',
    'nmap -sS -A target.corp',
    'az ad signed-in-user show',
    'python3 rat_analyzer.py --sample discord_c2.exe',
  ],
  bio: `Pentest Intern at RandoriSec and Post-Master's student at EURECOM
in the SUP'COM × EURECOM program — Security of Computer Systems
and Communications. I like shells on cloud tenants, adversarial
ML, and writing tools that are uncomfortably effective.`,
  skills: {
    Security: ['Azure Red Team', 'Active Directory', 'Web Pentest', 'Malware Analysis', 'Privilege Escalation', 'C2 Dev'],
    Tooling:  ['Rust', 'Python', 'PowerShell', 'Bash', 'Go', 'C/C++', 'Docker', 'Linux'],
    'AI / ML': ['Adversarial ML', 'PyTorch', 'LLM Evaluation', 'LSTM / GRU', 'Anomaly Detection', 'ZK-SNARK'],
  },
  projects: [
    {
      id: 'azure-rt',
      name: 'Azure Red Team Arsenal',
      cat: 'Security',
      year: '2026',
      nda: true,
      summary: 'Suite of Azure tenant enumeration + abuse primitives. Covers graph, devicecode phish, service principal pivoting.',
      stack: ['Python', 'PowerShell', 'Azure CLI', 'Graph API'],
      status: 'active',
    },
    {
      id: 'zk-rust',
      name: 'ZK-SNARK in Rust',
      cat: 'Systems',
      year: '2025',
      summary: 'From-scratch implementation of a Groth16 verifier in safe Rust. Bilinear pairing math + trusted setup.',
      stack: ['Rust', 'ark-works', 'bls12-381'],
      status: 'shipped',
    },
    {
      id: 'llm-spoof',
      name: 'LLM Spoof Detection',
      cat: 'AI',
      year: '2025',
      summary: 'Classifier + watermark residuals for detecting AI-generated content in security reporting pipelines.',
      stack: ['PyTorch', 'HF Transformers', 'Numpy'],
      status: 'research',
    },
    {
      id: 'discord-rat',
      name: 'Discord RAT Research',
      cat: 'Security',
      year: '2024',
      summary: 'Reverse engineering of commodity Discord-based C2 trojans. IOC extraction + detection rules.',
      stack: ['IDA', 'Python', 'YARA', 'Wireshark'],
      status: 'shipped',
    },
    {
      id: 'energy-lstm',
      name: 'Energy Forecasting LSTM',
      cat: 'AI',
      year: '2024',
      summary: 'LSTM/GRU ensemble for short-horizon electrical load forecasting on Tunisian grid data.',
      stack: ['PyTorch', 'Pandas', 'Keras'],
      status: 'shipped',
    },
    {
      id: 'web-ctf',
      name: 'CTF Writeups & Tools',
      cat: 'Web',
      year: '2024',
      summary: 'Collection of solved web / crypto / pwn challenges with custom exploit scripts.',
      stack: ['Python', 'Burp', 'pwntools'],
      status: 'shipped',
    },
  ],
  experience: [
    { role: 'Pentest Intern', org: 'RandoriSec', date: '2026 —', bullets: ['Azure red-team engagements', 'Internal AD assessments', 'Tool dev in Python/PowerShell'] },
    { role: 'Post-Master Student', org: 'EURECOM × SUP\'COM', date: '2025 — 2026', bullets: ['Security of Computer Systems & Communications', 'Applied cryptography, adversarial ML', 'Thesis: offensive use of LLMs'] },
    { role: 'Research Intern', org: 'Tunisian Grid Lab', date: '2024', bullets: ['Load forecasting with LSTM/GRU', 'Dataset cleaning and feature engineering'] },
    { role: 'Engineer Degree', org: 'SUP\'COM', date: '2020 — 2025', bullets: ['Telecom engineering, security focus', 'Top 5% of cohort'] },
  ],
  contact: {
    email: 'bahaeddine.melki@eurecom.fr',
    github: 'github.com/bmelki',
    linkedin: 'linkedin.com/in/bahaeddine-melki',
    pgp: 'A3F1 9C2D … 88EE',
  },
};

const PROJECT_CATS = ['All', 'Security', 'AI', 'Systems', 'Web'];

Object.assign(window, { MatrixRain, Glitch, Typewriter, DecryptText, ScrollReveal, PORTFOLIO, PROJECT_CATS });
